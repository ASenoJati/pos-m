@php $totalPayment=0 @endphp @foreach ($getCustomerItem as $item)
<tr>
    <td>{{ $item->item->name }}</td>
    <td>
        <div class="btn-group" role="group" aria-label="Basic example">
            @if ($item->qty==1)
            <button
                type="button"
                class="btn btn-primary"
                data-id="{{ $item->id }}"
                id="deleteItem{{ $item->id }}"
            >
                <i class="bi bi-trash3"></i>
            </button>
            @else
            <button type="button" class="btn btn-primary">
                <i class="bi bi-dash-square"></i>
            </button>
            @endif
            <input
                type="number"
                class="form-control"
                id=""
                value="{{ $item->qty }}"
            />
            <button
                type="button"
                class="btn btn-primary"
                data-id="{{ $item->id }}"
                id="plusItem{{ $item->id }}"
            >
                <i class="bi bi-plus-square"></i>
            </button>
        </div>
    </td>
    <td>@currency($item->item->price)</td>
    <td>@currency($item->discount)</td>
    <td>@currency($item->item->price*$item->qty-$item->discount)</td>
    <td>{{ $item->note }}</td>
    <td>
        <a
            href="#"
            class="btn btn-danger delete"
            data-id="{{ $item->id }}"
            id="deleteItem{{ $item->id }}"
        >
            DEL</a
        >
    </td>
</tr>
@php $totalPayment+=$item->item->price*$item->qty-$item->discount @endphp
@endforeach
<tr>
    <td class="bg-info"><h4>TOTAL @currency($totalPayment)</h4></td>
</tr>
<script src="{{ asset('vendor/jquery/jquery.min.js') }}"></script>
<script>
    localStorage.setItem("pay", {{ $totalPayment }})
</script>
@foreach ($getCustomerItem as $item)
<script>
    $("#deleteItem{{ $item->id }}").click(function (e) {
        e.preventDefault();
        var id = $(this).data("id");
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });
        $.ajax({
            url: "/customer/itemdel/{{ $track_id }}/" + id,
            method: "DELETE",
            success: function (result) {
                if (result.errors) {
                    console.log(result.errors);
                } else {
                    console.log("ok");
                    showMember();
                }
            },
        });
    });
    $("#plusItem{{ $item->id }}").click(function (e) {
        e.preventDefault();
        var id = $(this).data("id");
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });
        $.ajax({
            url: "/customer/itemdel/{{ $track_id }}/" + id,
            method: "DELETE",
            success: function (result) {
                if (result.errors) {
                    console.log(result.errors);
                } else {
                    console.log("ok");
                    showMember();
                }
            },
        });
    });
</script>
@endforeach
